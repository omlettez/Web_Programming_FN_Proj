window.onload = start

function start()
{
    document.getElementById('errormsg').innerHTML = "";
    ///////////////////////
    const queryString = window.location.search;
	const urlParams = new URLSearchParams(queryString);
	if (urlParams.get("error")==1)
    {
		document.getElementById('errormsg').innerHTML = "Password must be at least 8 character";
        setTimeout(() => document.getElementById('errormsg').innerHTML = "", 5000);
    }
    if (urlParams.get("error")==5)
    {
		document.getElementById('errormsg').innerHTML = "This e-mail is taken.";
        setTimeout(() => document.getElementById('errormsg').innerHTML = "", 5000);
    }
}
