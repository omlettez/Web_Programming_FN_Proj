///////// WORKFLOW ////////
window.onload = pageload;
////// ONLOAD WORKFLOW ///////
function pageload()
{
    CreatetableDatabase();
    getData();
    //checkCookie();
}
///////// SCRIPT MAIN PAGE AREA /////////|
//Checkguest

//GetCookie


//Getitemdata
function getData()
{
    Getnumberofitemfromdatabase();
}
async function CreatetableDatabase()
{
    await fetch('/createtable')
}
async function Getnumberofitemfromdatabase()
{
    const res = await fetch('/getitem')
    const data = await res.json();
    let keys = Object.keys(data);
    if (keys.length != 0)
    {
        for (let i = 0; i < keys.length; i++)
        {
            let temp = data[keys[i]];
            let Amtdata = temp.amountofbuyableitems;
            let Price = temp.price;

            if (Price === 0)
            {
                document.getElementById('price'+(i+1)).innerHTML = "Free";
            }
            else
            {
                document.getElementById('price'+(i+1)).innerHTML = Price.toString() + ".-";
            }
            if (Amtdata === 0)
            {
                document.getElementById('pdamt'+(i+1)).innerHTML = "Out of stock";
                document.getElementById('price'+(i+1)).innerHTML = "";
            }
            else
            {
                document.getElementById('pdamt'+(i+1)).innerHTML = Amtdata.toString();
            }
        }
    }
}