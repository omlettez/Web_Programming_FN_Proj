window.onload = start;
var test = 10;
function start() 
{
    /////// INTINAL FUNCTION //////
    var a = document.getElementById("profile");
    var b = document.getElementById("b&c");
    var c = document.getElementById("address");
    var d = document.getElementById("pw");
    var e = document.getElementById("deli");
    var f = document.getElementById("dis");
    a.style.display = "block";
    b.style.display = "none";
    c.style.display = "none";
    d.style.display = "none";
    e.style.display = "none";
    f.style.display = "none";
    ////// MY FUNCTION /////////
    document.getElementById('submitpassword').onclick = Changepassword;
    document.getElementById('submitprofile').onclick = submitprofile;
    document.getElementById('submityouraddress').onclick = submitaddress;
    document.getElementById('filefield').onchange = fileSubmit;
    document.getElementById('displayPic').onclick = fileUpload;
    GetaccountdatatoFORM();

}

async function GetaccountdatatoFORM()
{
    const res = await fetch('/getaccountdata');
    console.log(res);
    const data = await res.json();
    let keys = Object.keys(data);
    let temp = data[keys];
    //let ID = temp.id;
    let Username = temp.username;
    let Email = temp.email;
    let Password = temp.password;
    let Phonenumber = temp.phonenumber;
    let Fullname = temp.fullname;
    let Gender = temp.gender;
    let dOB = temp.DOB;
    let Address = temp.address;
    //let Img = temp.img;

    ///// SET FORM Profile /////
    document.getElementById('username').value = Username;
    document.getElementById('email').value = Email;
    document.getElementById('phone').value = Phonenumber;
    document.getElementById('fileField').onchange = fileSubmit;
    switch (Gender)
    {
        case 'Male':
        {
            document.getElementById('Female').checked = false;
            document.getElementById('Other').checked = false;
            document.getElementById('Male').checked = true;
            break;
        }
        case 'Female':
        {
            document.getElementById('Other').checked = false;
            document.getElementById('Male').checked = false;
            document.getElementById('Female').checked = true;
            break;
        }
        case "Other":
        {
            document.getElementById('Female').checked = false;
            document.getElementById('Male').checked = false;
            document.getElementById('Other').checked = true;
        }
    }
    document.getElementById('dateofbirth').value = dOB;

    ///// SET ADRESSES Profile /////
    document.getElementById('fullnameataddress').value = Fullname;
    document.getElementById('phonenumber').value = Phonenumber;
    document.getElementById('address').value = Address;

    //// Delivery status ////

    //// My discounts /////
    
    //document.getElementById('password') = Password;
}
async function submitaddress(Fullname, Phonenumber, Email, Address)
{
    let Fullname = document.getElementById('fullnameataddress').value;
    let Phonenumber = document.getElementById('phonenumber').value;
    let Email = document.getElementById('email').value;
    let Address = document.getElementById('address').value;
    const res = await fetch("/submitaddress",
    {
		method: "POST",
		headers: 
        {
			'Accept': 'application/json',
			'Content-Type': 'application/json'
		},
		body: JSON.stringify
        ({
			Fname : Fullname,
			Pnum : Phonenumber,
            Adr : Address,
            Mail : Email
        })
	});
    if (res === true)
    {
        document.getElementById('profilestatus').innerHTML = "Your address has been changed."
        setTimeout(() => document.getElementById('Changepassresult').innerHTML = "", 5000);
    }
    else
    {
        document.getElementById('profilestatus').innerHTML = "Error."
        setTimeout(() => document.getElementById('Changepassresult').innerHTML = "", 5000);
    }
}

async function Changepassword()
{
    let oldpassword = document.getElementById('OLDPW').value;
    let newpassword = document.getElementById('NEWPW').value;
    let Email = document.getElementById('email').value;
    const res = await fetch("/changepassword",{
		method: "POST",
		headers: 
        {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
		},
		body: JSON.stringify
        ({
			oldpw : oldpassword,
			newpw : newpassword,
            EMAIL : Email
        })
	});
    document.getElementById('OLDPW').value = "";
    document.getElementById('NEWPW').value = "";
    if (res === true)
    {
        document.getElementById('Changepassresult').innerHTML = "Password has been changed successfully."
        return setTimeout(() => document.getElementById('Changepassresult').innerHTML = "", 5000);
    }
    else
    {
        document.getElementById('Changepassresult').innerHTML = "Wrong old password."
        return setTimeout(() => document.getElementById('Changepassresult').innerHTML = "", 5000);
    }
}
async function submitprofile()
{
    let Username = document.getElementById('username').value;
    let Email = document.getElementById('email').value;
    let Phonenumber = document.getElementById('phone').value;
    let Fullname = document.getElementById('fullnameprofile').value;

    let Gender;  
    const radioButtons = document.querySelectorAll('input[name="Gender"]');
        btn.addEventListener("click", () => 
        {
            for (const radioButton of radioButtons) 
            {
                if (radioButton.checked)
                {
                    document.getElementById("myRadio");
                    Gender = radioButton.value;
                    break;
                }
            }
        });
    let dOB = document.getElementById('dateofbirth').value;
    ///// POST Profile to DATABASE /////
    const res = await fetch("/submitprofile",
    {
        method: "POST",
		headers: 
        {
			'Accept': 'application/json',
			'Content-Type': 'application/json'
		},
		body: JSON.stringify
        ({
			User : Username,
            Mail : Email,
            Pnumber : Phonenumber,
            Fname : Fullname,
            Gend : Gender,
            Dob : dOB
        })
    });
    if (res === true)
    {
        document.getElementById('profilestatus').innerHTML = "Your profile has been changed.";
        setTimeout(() => document.getElementById('Changepassresult').innerHTML = "", 5000);
    }
    else
    {
        document.getElementById('profilestatus').innerHTML = "Wrong old password.";
        setTimeout(() => document.getElementById('Changepassresult').innerHTML = "", 5000);
    }
}




///////////////PERKS////////////////////
function myProfile() {
    var a = document.getElementById("profile");
    var b = document.getElementById("b&c");
    var c = document.getElementById("address");
    var d = document.getElementById("pw");
    var e = document.getElementById("deli");
    var f = document.getElementById("dis");
    if (a.style.display === "none") {
        a.style.display = "block";
        b.style.display = "none";
        c.style.display = "none";
        d.style.display = "none";
        e.style.display = "none";
        f.style.display = "none";
    }
}
function myBankandcards() {
    var a = document.getElementById("profile");
    var b = document.getElementById("b&c");
    var c = document.getElementById("address");
    var d = document.getElementById("pw");
    var e = document.getElementById("deli");
    var f = document.getElementById("dis");
    if (b.style.display === "none") {
        b.style.display = "block";
        a.style.display = "none";
        c.style.display = "none";
        d.style.display = "none";
        e.style.display = "none";
        f.style.display = "none";
    }
}
function myAddress() {
    var a = document.getElementById("profile");
    var b = document.getElementById("b&c");
    var c = document.getElementById("address");
    var d = document.getElementById("pw");
    var e = document.getElementById("deli");
    var f = document.getElementById("dis");
    if (c.style.display === "none") {
        c.style.display = "block";
        a.style.display = "none";
        b.style.display = "none";
        d.style.display = "none";
        e.style.display = "none";
        f.style.display = "none";
    }
}
function myPass() {
    var a = document.getElementById("profile");
    var b = document.getElementById("b&c");
    var c = document.getElementById("address");
    var d = document.getElementById("pw");
    var e = document.getElementById("deli");
    var f = document.getElementById("dis");
    if (d.style.display === "none") {
        d.style.display = "block";
        a.style.display = "none";
        b.style.display = "none";
        c.style.display = "none";
        e.style.display = "none";
        f.style.display = "none";
    }
}
function myDeli() {
    var a = document.getElementById("profile");
    var b = document.getElementById("b&c");
    var c = document.getElementById("address");
    var d = document.getElementById("pw");
    var e = document.getElementById("deli");
    var f = document.getElementById("dis");
    if (e.style.display === "none") {
        e.style.display = "block";
        a.style.display = "none";
        b.style.display = "none";
        c.style.display = "none";
        d.style.display = "none";
        f.style.display = "none";
    }
}
function myDis() {
    var a = document.getElementById("profile");
    var b = document.getElementById("b&c");
    var c = document.getElementById("address");
    var d = document.getElementById("pw");
    var e = document.getElementById("deli");
    var f = document.getElementById("dis");
    if (f.style.display === "none") {
        f.style.display = "block";
        a.style.display = "none";
        b.style.display = "none";
        c.style.display = "none";
        d.style.display = "none";
        e.style.display = "none";
    }
}
function fileUpload()
{
	document.getElementById('fileField').click();
}


function fileSubmit()
{
	document.getElementById('formId').submit();
}