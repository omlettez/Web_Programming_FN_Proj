const express = require('express');
const app = express();
const fs = require('fs');
const hostname = 'localhost';
const port = 3000;
const bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
const multer = require('multer');
const path = require('path');
const mysql = require('mysql');
const { get } = require('https');

app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(cookieParser());

const storage = multer.diskStorage({
    destination: (req, file, callback) => {
      callback(null, 'img/');
    },

    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
  });

const imageFilter = (req, file, cb) => {
    // Accept images only
    if (!file.originalname.match(/\.(jpg|JPG|jpeg|JPEG|png|PNG|gif|GIF)$/)) {
        req.fileValidationError = 'Only image files are allowed!';
        return cb(new Error('Only image files are allowed!'), false);
    }
    cb(null, true);
};

// ใส่ค่าตามที่เราตั้งไว้ใน mysql
const con = mysql.createConnection
({
    host: "localhost",
    user: "ice",
    password: "566336",
    database: "finalwebapp"
})

con.connect
(err => 
{
    if(err) throw(err);
    else
    {
        console.log("MySQL connected");
    }
})

const queryDB = (sql) => {
    return new Promise((resolve,reject) => {
        // query method
        con.query(sql, (err,result, fields) => {
            if (err) reject(err);
            else
                resolve(result)
        })
    })
}

var myrecentemail;
//////////////// CREATE ALL TABLES /////////////////
app.get('/createtable', async (req,res) =>
{
    let sqlt1 = "CREATE TABLE IF NOT EXISTS userdatafinal (id INT AUTO_INCREMENT PRIMARY KEY, reg_date TIMESTAMP, username VARCHAR(255), email VARCHAR(255), password VARCHAR(100), pfp VARCHAR(255), phonenumber VARCHAR(15), fullname VARCHAR(255), gender VARCHAR(20), DOB VARCHAR(50), Address VARCHAR(500), img VARCHAR(200))";
    await queryDB(sqlt1);
    let sqlt2 = "CREATE TABLE IF NOT EXISTS amountofbuyableitems (id INT AUTO_INCREMENT PRIMARY KEY, reg_date TIMESTAMP, amountofbuyableitems INT, price INT, img VARCHAR(255), nameofproduct VARCHAR(255))";
    await queryDB(sqlt2);
    let sqlt3 = "CREATE TABLE IF NOT EXISTS iteminwatchlist (id INT AUTO_INCREMENT PRIMARY KEY, reg_date TIMESTAMP, amountofeitems INT)";
    await queryDB(sqlt3);
    let sqlt4 = "CREATE TABLE IF NOT EXISTS iteninchecklist (id INT AUTO_INCREMENT PRIMARY KEY, reg_date TIMESTAMP, amountofitems INT, price INT, img VARCHAR(255), nameofproduct VARCHAR(255), totalprice INT)";
    await queryDB(sqlt4);
}
)
//////////////// REGISTERATION AND VERIFYING ///////////////////

app.post('/regisDB', async (req,res) => 
{
    let tablename = 'userdatafinal';
    let password = req.body.password;
    if (password.length < 8)
    {
        return res.redirect('register.html?error=1');
    }
    else
    {
        const users = `SELECT email FROM ${tablename}`;
        let result = await queryDB(users);
        result = Object.assign({},result);
        console.log(result);
        if (Object.keys(result).length === 0)
        {
            let fullname = req.body.firstname + "  " + req.body.lastname;
            let username = req.body.firstname
            sql = `INSERT INTO userdatafinal 
            (username, email, password, fullname, pfp) 
            VALUES 
            (
                "${username}", 
                "${req.body.email}", 
                "${req.body.password}",
                "${fullname}",
                "avatar.png"
            )`;
            result = await queryDB(sql);
            return res.redirect('login.html');
        }
        else
        {
        let obj = Object.keys(result);
        for(var i = 0 ; i <= (obj.length - 1) ; i++)
        {
            let temp = result[obj[i]];
            console.log(temp);
            let Emaildata = temp.email;
            console.log(Emaildata);
            if (Emaildata == req.body.email)
            {
                return res.redirect('register.html?error=5'); 
            }
            else
            {
                let fullname = req.body.firstname + "  " + req.body.lastname;
                let username = req.body.firstname
                sql = `INSERT INTO userdatafinal 
                (username, email, password, fullname, pfp) 
                VALUES 
                (
                    "${username}", 
                    "${req.body.email}", 
                    "${req.body.password}",
                    "${fullname}",
                    "${'avatar.png'}"
                )`;
                result = await queryDB(sql);
                return res.redirect('login.html');
            }
        }
        }
    }
})

app.post('/verifybeforelogin', async(req,res) =>
{
    let tablename = 'userdatafinal';
    let sql = `SELECT id, email, password, img, username FROM ${tablename}`;
    let result = await queryDB(sql);
    result = Object.assign({},result);
    let obj = Object.keys(result);
    for(var i = 0 ; i <= (obj.length - 1) ; i++)
    {
        let temp = result[obj[i]];
        let Emaildata = temp.email;
        let Passworddata = temp.password;
        if (req.body.email === Emaildata && req.body.password === Passworddata)
        {
            let Imgdata = temp.img;
            res.cookie('email', req.body.email ,{path:"/"});
            res.cookie('img', Imgdata, {path:"/"});
            myrecentemail = req.body.email;
            return res.redirect('indexlogin.html')
        }
    }
    return res.redirect('login.html?error=1');
})

app.get('/logout', async(req,res) =>
{
    res.clearCookie('email');
    res.clearCookie('img');
    return res.redirect('index.html');
})
/////////////// ACCOUNT ADJUSTING ///////////////////
app.post('/profilepic',async (req,res) => 
{
    const uploadpic = multer({storage, fileFilter : imageFilter}).single('avatar')
    //
    uploadpic(req, res, async (err) => 
    {
        if (req.fileValidationError)
        {
            return res.send(req.fileValidationError)
        }
        else if (!req.file)
        {
            return res.send("Please choose image to your avatar.")
        }
        else if (err instanceof multer.MulterError)
        {
            return res.send(err)
        }
        else if (err)
        {
            return res.send(err)
        }
        res.cookie('img', req.file.filename)
        let myemail = getCookie('email');
        let tablename = 'userdatafinal';
        sql_msg = `INSERT INTO ${tablename} (img) VALUES ("${req.file.filename}") WHERE email = ("${myemail}")`;
        await queryDB(sql_msg);
        await updateImg(req.cookies.email, req.file.filename);
        return true;
    })
    function getCookie(name){
        var value = "";
        try
        {
            value = document.cookie.split("; ").find(row => row.startsWith(name)).split('=')[1]
            //value = req.headers.cookie.split("; ").find(row => row.startsWith(name)).split('=')[1]
            return value
        }catch(err){
            return false
        } 
    }
})
app.post('/personaldata', async (req,res) =>
{
    let tablename = 'userdatafinal';
    let sql = `UPDATE ${tablename} 
    SET 
        fullname = '${req.body.fullname}' 
        phonenumber = '${req.body.phonenumber}' 
        username = '${req.body.username}';
    WHERE 
        email = '${req.body.email}'`
    let result = await queryDB(sql);
    result = Object.assign({},result);
})
/////////////// GET ITEM FROM DATABASE //////////////
app.get('/getitem', async (req,res) =>
{
    let tablename = 'amountofbuyableitems';
    let sql = `SELECT id, amountofbuyableitems, price FROM ${tablename}`;
    let result = await queryDB(sql);
    result = Object.assign({},result);
    res.json(result);
})
/////////////////// ACCOUNT DATA /////////////////////
app.get('/getaccountdata', async (req,res) =>
{
        let mail = getCookie('email');
        let tablename = 'userdatafinal';
        let sql = `SELECT id, username, email, password, pfp, phonenumber, fullname, 
        gender, DOB, Address, img FROM ${tablename} WHERE email = ${mail}`;
        let result = await queryDB(sql);
        result = Object.assign({},result);
        res.json(result);

        function getCookie(name){
            var value = "";
            try
            {
                value = document.cookie.split("; ").find(row => row.startsWith(name)).split('=')[1]
                //value = req.headers.cookie.split("; ").find(row => row.startsWith(name)).split('=')[1]
                return value
            }
            catch(err)
            {
                return false
            } 
        }
})
app.post('/changepassword',async (req,res) =>
{
        let tablename = 'userdatafinal';
        let sql = `SELECT password FROM ${tablename} WHERE email = ${myrecentemail}`;
        let result = await queryDB(sql);
        result = Object.assign({},result);
        let obj = Object.keys(result);
        let temp = result[obj];
        //
        let obj2 = Object.keys(req.body);
        let temp2 = req.body[obj2];
        let Oldpw = temp2.oldpw;
        let Newpw = temp2.Newpw;
        let Email = temp2.EMAIL;
        ///
        let oldPasswordinDB = temp.password;
        ///
        if (Oldpw === oldPasswordinDB)
        {
            let sql_msg = `INSERT INTO ${tablename} (password) VALUES ("${Newpw}") WHERE email = ("${Email}")`;
            await queryDB(sql_msg);
            console.log("ReplacedPassword");
            return true;
        }
        else
        {
            console.log("Wrongoldpassword");
            return false;
        }
})

app.post('/submitprofile',async (req,res) =>
{
        let obj = (req.body);
        console.log(obj);
        let Username = obj.User;
        let Email = obj.Mail;
        let Phonenumber = obj.Pnumber;
        let Fullname = obj.Fname;
        let Gender = obj.Gend;
        let dOB = obj.Dob;
        
        let sql_msg = `INSERT INTO ${tablename} (username, phonenumber, fullname, gender, DOB) 
            VALUES 
                ("${Username}","${Phonenumber}","${Fullname}","${Gender}","${dOB}") 
            WHERE 
                email = ${Email}`;
        await queryDB(sql_msg);
})

app.post('/submitaddress', async (req,res) =>
{
        let obj = (req.body);
        let temp = req.body[obj];
        let Fullname = temp.Fname;
        let Phonenumber = temp.Pnum;
        let Address = temp.Adr;
        let Email = temp.Mail;
        let sql_msg = `INSERT INTO ${tablename} (fullname, phonenumber, Address)
            VALUES 
                ("${Fullname}","${Phonenumber}","${Address}") 
            WHERE 
                email = ${Email}`;
        await queryDB(sql_msg);
})
///////////////////////////////////////////////
app.post('/getproduct'), async (req,res) =>
{
    let tablename = 'amountofbuyableitems';
    console.log(req.body);
    let keys = Object.keys(req.body);
    let temp = req.body[keys]
    let lastchar = temp.lastword;
    let sql = `SELECT id, amountofbuyableitems, price, img, nameofproduct FROM ${tablename} WHERE id = ${lastchar}`;
    let result = await queryDB(sql);
    result = Object.assign({},result);
    res.json(result);
}

app.post('/gochecklist', async (req,res) =>
{

})
///////////////////////////////////////////////
app.listen(port, hostname, () => 
{
    console.log(`Server running at http://${hostname}:${port}/index.html`);
})